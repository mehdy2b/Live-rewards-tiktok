
export default async (req) => {
  try {
    const url = new URL(req.url);
    let username = (url.searchParams.get("username") || "").trim().replace(/^@+/, "");

    if (!username || !/^[A-Za-z0-9._]{2,24}$/.test(username)) {
      return new Response(JSON.stringify({ error: "Invalid username" }), {
        status: 400,
        headers: { "content-type": "application/json; charset=utf-8" }
      });
    }

    const profileUrl = `https://www.tiktok.com/@${encodeURIComponent(username)}`;
    const endpoint = `https://www.tiktok.com/oembed?url=${encodeURIComponent(profileUrl)}`;

    const r = await fetch(endpoint, {
      headers: { "user-agent": "Mozilla/5.0" }
    });

    if (!r.ok) {
      return new Response(JSON.stringify({ error: "Profile unavailable or not embeddable" }), {
        status: 404,
        headers: { "content-type": "application/json; charset=utf-8" }
      });
    }

    const data = await r.json();
    return new Response(JSON.stringify({
      username,
      profile_url: profileUrl,
      title: data.title || "",
      author_name: data.author_name || "",
      author_url: data.author_url || profileUrl,
      html: data.html || ""
    }), {
      status: 200,
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "public, max-age=300"
      }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: "Server error" }), {
      status: 500,
      headers: { "content-type": "application/json; charset=utf-8" }
    });
  }
};
